<?php defined('ABSPATH') or die('Cheatin\' Uh?'); ?>

<div id="incredibbble-unsupported" class="notice error is-dismissible">
    <p><?php _e('Your current theme does not support Incredibble plugin.', 'incredibble'); ?></p>
</div>